# Android Lifecycle

Android Lifecycle and Shared Preference

## Screenshots

### Shared Preference sebelum di handle
<img src="https://github.com/nuryadincjr/android-lifecycle/blob/main/img/1.gif" width="233" height="483">

### Shared Preference setelah di handle

<img src="https://github.com/nuryadincjr/android-lifecycle/blob/main/img/2.gif" width="233" height="483">
